<?php
include 'get-parameters.php';
$conn = new mysqli($ep, $un, $pw, $db);
include 'population.php';
?>
